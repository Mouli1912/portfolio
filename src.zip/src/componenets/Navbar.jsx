function Navber(){
    return (
        <nav>
            <ul>
                <li>Home</li>
                <li>About</li>
                <li>Contact</li>
                <li>projects</li>
                <li>Skills</li>
            </ul>
            
        </nav>
    )
}
export default Navber;